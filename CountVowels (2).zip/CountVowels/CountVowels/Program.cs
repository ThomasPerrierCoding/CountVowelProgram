﻿using System;

namespace CountVowels
{
    class Program
    {
        static void Main(string[] args)
        {
            string userIn = "";
            int vowels = 0;
            int cnt = 0;
            while (cnt == 0)
            {
                Console.Write("Please enter phase: ");
                userIn = Console.ReadLine();
                if(userIn=="")
                {
                    Console.WriteLine("Input was invalid. Input was left blank");
                } 
                else
                {
                    foreach(char c in userIn.ToUpper())
                    {
                        if(c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
                        {
                            vowels++;
                        }
                    }
                    cnt = 1;
                }
            }
            Console.WriteLine("The number of vowels in your phrase was: " + vowels);
            Console.ReadKey();
        }
    }
}
